﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Mahen_Thinkbridge.Models;
using System.Data;
using System.ComponentModel;
namespace Mahen_Thinkbridge.Controllers
{
    public class InventoryController : ApiController
    {
        public IHttpActionResult GetAllInventory()
        {
            try
            {
                IList<InventoryViewModel> inventory = null;

                using (var ctx = new ThinkbridgeEntities())
                {
                    inventory = ctx.tblInventories
                                .Select(s => new InventoryViewModel()
                                {
                                    InventoryId = s.InventoryId,
                                    InventoryName = s.InventoryName,
                                    Description = s.Description,
                                    InventoryPrice = Convert.ToDecimal(s.InventoryPrice),
                                    Qty = Convert.ToInt32(s.Qty),
                                    Status = Convert.ToInt32(s.Status),
                                    CreatedBy = s.CreatedBy,
                                    ModifiedBy = s.ModifiedBy,
                                    CreationDate = Convert.ToDateTime(s.CreationDate),
                                    ModifiedDate = Convert.ToDateTime(s.ModifiedDate)
                                }).ToList<InventoryViewModel>();
                }

                if (inventory.Count == 0)
                {
                    return NotFound();
                }

                return Ok(inventory);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid data.");
               
            }
        }
        //Get:api/Inventorys/1
        public IHttpActionResult GetInventoryById(int id)
        {
            try
            {
                InventoryViewModel inventroy = null;

                using (var ctx = new ThinkbridgeEntities())
                {
                    inventroy = ctx.tblInventories
                        .Where(s => s.InventoryId == id)
                        .Select(s => new InventoryViewModel()
                        {
                            InventoryName = s.InventoryName,
                            Description = s.Description,
                            InventoryPrice = Convert.ToDecimal(s.InventoryPrice),
                            Qty = Convert.ToInt32(s.Qty),
                            Status = Convert.ToInt32(s.Status),
                            CreatedBy = s.CreatedBy,
                            ModifiedBy = s.ModifiedBy,
                            CreationDate = Convert.ToDateTime(s.CreationDate),
                            ModifiedDate = Convert.ToDateTime(s.ModifiedDate)
                        }).FirstOrDefault<InventoryViewModel>();
                }

                if (inventroy == null)
                {
                    return NotFound();
                }

                return Ok(inventroy);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid data.");
                throw;
                
            }
        }
        //Get action methods of the previous section
    public IHttpActionResult PostNewInventory(InventoryViewModel inventory)
    {
            try
            {
                    if (!ModelState.IsValid)
                        return BadRequest("Invalid data.");

                    using (var ctx = new ThinkbridgeEntities())
                    {
                        ctx.tblInventories.Add(new tblInventory()
                        {
                            InventoryName = inventory.InventoryName,
                            Description = inventory.Description,
                            InventoryPrice = Convert.ToDecimal(inventory.InventoryPrice),
                            Qty = Convert.ToInt32(inventory.Qty),
                            Status = Convert.ToBoolean(inventory.Status),
                            CreatedBy = inventory.CreatedBy,
                            ModifiedBy = inventory.ModifiedBy,
                            CreationDate = Convert.ToDateTime(inventory.CreationDate),
                            ModifiedDate = Convert.ToDateTime(inventory.ModifiedDate)
                        });

                        ctx.SaveChanges();
                    }

                    return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid data.");
                throw;
            }
     }

    public IHttpActionResult Put(InventoryViewModel inventory)
    {
            try 
	        {	        
		
                if (!ModelState.IsValid)
                    return BadRequest("Not a valid model");

                using (var ctx = new ThinkbridgeEntities())
                {
                    var existingInv = ctx.tblInventories.Where(s => s.InventoryId == inventory.InventoryId)
                                                            .FirstOrDefault<tblInventory>();

                    if (existingInv != null)
                    {
                        existingInv.InventoryName = inventory.InventoryName;
                        existingInv.InventoryPrice = inventory.InventoryPrice;

                        ctx.SaveChanges();
                    }
                    else
                    {
                        return NotFound();
                    }
                }

                return Ok();
	        }
	        catch (Exception)
	        {
                return BadRequest("Invalid data.");
		        throw;
	        }
    }
}
    }

