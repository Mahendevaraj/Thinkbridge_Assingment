﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mahen_Thinkbridge.Models
{
    public class InventoryViewModel
    {

        public int InventoryId { get; set; }
        public string InventoryName { get; set; }
        public string Description { get; set; }
        public decimal InventoryPrice { get; set; }
        public int Qty { get; set; }
        public int Status { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime ModifiedDate { get; set; }

    }
}