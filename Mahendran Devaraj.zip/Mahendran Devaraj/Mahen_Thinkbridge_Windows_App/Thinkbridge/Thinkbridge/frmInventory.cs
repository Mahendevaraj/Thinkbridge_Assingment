﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Windows.Forms;
using System.Net;
using System.Xml;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Text;
using System.Runtime;

using System.Net.Configuration;


namespace Thinkbridge
{
    public partial class frmInventory : Form
    {
        public frmInventory()
        {
            InitializeComponent();
        }

        private void btnGetInventory_Click(object sender, EventArgs e)
        {
            var inventory = GetInvenorybyId();
        }

        private string GetInvenorybyId(int id)
        {
            try
            {
               


                string xmlString = "";
              
                string heartbeatURL = "http://localhost:57227/Help/Api/GET-api-Inventory-id/"+id;
                xmlString = Get(heartbeatURL);
               
                return xmlString;
            }
            catch (Exception ex)
            {

            
                return null;
            }
        }

        public static string Get(string uri)
        {
            try
            {
               
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
               

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {

               
                return null;
            }
        }
    }
}
